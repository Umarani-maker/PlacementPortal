package com.bootapp.placemenportal.model;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Lob;
import java.util.Date;
@Data
public class CompanyAddRequest {

    private int company_id;
    private float aggregate_10th;
    private float aggregate_12th;
    private String company_name;
    private byte[] company_logo;
    private String company_url;
    private long cost_to_company;
    private Date deadline_to_apply;
    private String eligible_department;
    private int no_of_standingarrear;
    private float required_cgpa;

}
