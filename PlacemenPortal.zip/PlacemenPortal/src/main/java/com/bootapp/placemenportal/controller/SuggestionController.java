package com.bootapp.placemenportal.controller;

import com.bootapp.placemenportal.entity.Suggestion;
import com.bootapp.placemenportal.model.SuggestionAddRequest;
import com.bootapp.placemenportal.service.SuggesionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class SuggestionController {



        @Autowired
        private SuggesionService suggesionService;


        @PostMapping("/addSuggesion")
        public Suggestion postDetails(@RequestBody SuggestionAddRequest suggestion)
        {
           return suggesionService.saveDetails(suggestion);


        }
}


