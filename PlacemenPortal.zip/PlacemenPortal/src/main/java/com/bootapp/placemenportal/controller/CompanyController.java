package com.bootapp.placemenportal.controller;

import com.bootapp.placemenportal.entity.Company;
import com.bootapp.placemenportal.entity.Student;
import com.bootapp.placemenportal.model.CompanyAddRequest;
import com.bootapp.placemenportal.service.CompanyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.Date;
import java.util.List;

@RestController
@CrossOrigin("*")
public class CompanyController {

        @Autowired
        private CompanyService companyService;


//        @PostMapping("/addCompany")
//        public Company postDetails(@RequestBody CompanyAddRequest company)
//        {
//
//            return companyService.saveDetail(company);
//
//        }
    @PostMapping("/addCompany")
    public String postDetails(@RequestParam("company_name") String company_name,
                               @RequestParam("company_url") String company_url,
                               @RequestParam("company_logo") MultipartFile company_logo,
                               @RequestParam("eligible_departments") String eligible_departments,
                               @RequestParam("aggregate_10th") float aggregate_10th,
                               @RequestParam("aggregate_12th") float aggregate_12th,
                               @RequestParam("required_cgpa") float required_cgpa,
                               @RequestParam("no_of_standingarrear") int no_of_standingarrear,
                               @RequestParam("deadline_to_apply") Date deadline_to_apply,
                               @RequestParam("cost_to_company") Long cost_to_company)throws IOException
    {

        companyService.saveDetail(company_name,company_url,company_logo,eligible_departments,aggregate_10th,aggregate_12th,
                required_cgpa,no_of_standingarrear,deadline_to_apply,cost_to_company);
        return "company added successfully";

    }

        @GetMapping("/getCompanyById/{id}")
        public Company fetchDatailsById(@PathVariable int id)
        {
            return companyService.getCompanyById(id);

        }

        @GetMapping("/allcompanies")
        public List<Company> getAllStudents() {
            return companyService.getAllCompanies();
        }

    }
