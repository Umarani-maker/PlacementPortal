package com.bootapp.placemenportal.controller;

import com.bootapp.placemenportal.entity.Student;
import com.bootapp.placemenportal.model.StudentAddRequest;
import com.bootapp.placemenportal.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import java.util.List;

@RestController
@CrossOrigin("*")
public class StudentController {
    @Autowired
    private StudentService studentService;


    @PostMapping("/addStudent")
    public Student postDetails(@RequestBody StudentAddRequest student)
    {
        return studentService.saveDetails(student);

    }

    @GetMapping("/getStudentById/{id}")
    public Student fetchDatailsById(@PathVariable int id)
    {
        return studentService.getStudentDetailsById(id);

    }


    @PutMapping("/updateStudent")
    public Student updateStudentDetails(@RequestBody Student student)
    {
        return studentService.updateDetails(student);
    }


    @DeleteMapping("deleteStudent/{id}")
    public String deletefunction(@PathVariable int id)
    {
        return studentService.deleteStudent(id);

    }

    @GetMapping("/allstudents")
    public List<Student> getAllStudents() {
        return studentService.getAllStudents();
    }


    @GetMapping("student/{emailId}")
    public ResponseEntity<Student> getStudentByEmail(@PathVariable String emailId) {
        Student student = studentService.getStudentByEmail(emailId);
        if (student != null) {
            return ResponseEntity.ok(student);
        } else {
            return ResponseEntity.notFound().build();
        }
    }



}
