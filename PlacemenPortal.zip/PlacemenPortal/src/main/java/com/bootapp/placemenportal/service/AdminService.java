package com.bootapp.placemenportal.service;

import com.bootapp.placemenportal.entity.Admin;
import com.bootapp.placemenportal.entity.Company;
import com.bootapp.placemenportal.model.AdminAddRequest;
import com.bootapp.placemenportal.repository.AdminRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
@Service
public class AdminService {

        @Autowired
        private AdminRepo adminRepo;



        public Admin saveDetails(AdminAddRequest admin)
        {

            Admin ad = new Admin();
            ad.setAdmin_id(admin.getAdmin_id());
            ad.setAdmin_name(admin.getAdmin_name());
            ad.setAdmin_email_id(admin.getAdmin_email_id());
            ad.setAdmin_password(admin.getAdmin_password());
            return adminRepo.save(ad);
        }

    }
