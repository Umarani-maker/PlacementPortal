package com.bootapp.placemenportal.entity;

import jdk.jshell.SourceCodeAnalysis;
import lombok.*;

import javax.persistence.*;
import java.util.Set;

@Entity
@Data
@Table(name="placement_student")
@NoArgsConstructor
@AllArgsConstructor
public class Student {
    @Id
    @Column(name="student_id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int student_id;

    @Column(name="student_name")
    private String student_name;

    @Column(name="reg_num")
    private int reg_num;

    @Column(name="email_id")
    private String email_id;

    @Column(name="ph_no")
    private Long ph_no;

    @Column(name="department")
    private String department;

    @Column(name="student_10th_aggregate")
    private float student_10th_aggregate;

    @Column(name="student_12th_aggregate")
    private float student_12th_aggregate;

    @Column(name="student_cgpa")
    private float student_cgpa;

    @Column(name="student_standing_arrear")
    private int student_standing_arrear;

    @Column(name="st_ad_id")
    private int admin_id;

    @OneToMany(cascade = CascadeType.ALL ,targetEntity = Suggestion.class)
    @JoinColumn(name="st_suggest_id",insertable = false,updatable = false)
    private Set<SourceCodeAnalysis.Suggestion> suggestion;

    @ManyToOne(cascade = CascadeType.ALL ,targetEntity = Admin.class)
    @JoinColumn(name="st_ad_id",referencedColumnName ="admin_id",insertable = false,updatable = false)
    private Admin admin;


}
