package com.bootapp.placemenportal.repository;

import com.bootapp.placemenportal.entity.Admin;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AdminRepo extends JpaRepository<Admin,Integer> {
}
