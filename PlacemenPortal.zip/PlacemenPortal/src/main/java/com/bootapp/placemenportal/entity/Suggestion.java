package com.bootapp.placemenportal.entity;

import jdk.jshell.SourceCodeAnalysis;
import lombok.*;

import javax.persistence.*;
import java.util.Set;


@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name ="placement_suggestion")
public class Suggestion {

        @Id
        @GeneratedValue
        int id;

//        @Id
//        @Column(name="suggestion_id")
//        @GeneratedValue(strategy = GenerationType.IDENTITY)
//        private int suggestion_id;

        @Column(name="suggestion")
        private String suggestion;



}






