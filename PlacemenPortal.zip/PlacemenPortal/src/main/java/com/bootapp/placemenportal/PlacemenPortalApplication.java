package com.bootapp.placemenportal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PlacemenPortalApplication {

    public static void main(String[] args) {
        SpringApplication.run(PlacemenPortalApplication.class, args);
    }

}
