package com.bootapp.placemenportal.service;

import com.bootapp.placemenportal.entity.Company;
import com.bootapp.placemenportal.entity.Student;
import com.bootapp.placemenportal.model.CompanyAddRequest;
import com.bootapp.placemenportal.repository.CompanyRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.Date;
import java.util.List;


@Service
public class CompanyService {

    @Autowired
    private CompanyRepo companyRepo;


    @PostMapping
    public void saveDetail(String company_name,String company_url,MultipartFile company_logo,String eligible_departments,float aggregate_10th,float aggregate_12th,
                           float required_cgpa,int no_of_standingarrear,Date deadline_to_apply,Long cost_to_company)throws IOException
    {
        if(!company_logo.isEmpty())
        {
            Company company = new Company();
            company.setCompany_name(company_name);
            company.setCompany_url(company_url);
            company.setAggregate_10th(aggregate_10th);
            company.setAggregate_12th(aggregate_12th);
            company.setRequired_cgpa(required_cgpa);
            company.setEligible_department(eligible_departments);
            company.setNo_of_standingarrear(no_of_standingarrear);
            company.setDeadline_to_apply(deadline_to_apply);
            company.setCost_to_company(cost_to_company);
            company.setCompany_logo(company_logo.getBytes());
            companyRepo.save(company);

        }

    }



//        public Company saveDetail (CompanyAddRequest company)
//        {
//
//
//            Company com = new Company();
//            com.setCompany_id(company.getCompany_id());
//            com.setCompany_name(company.getCompany_name());
//            com.setCompany_logo(company.getCompany_logo());
//            com.setCompany_url(company.getCompany_url());
//            com.setEligible_department(company.getEligible_department());
//            com.setAggregate_10th(company.getAggregate_10th());
//            com.setAggregate_12th(company.getAggregate_12th());
//            com.setRequired_cgpa(company.getRequired_cgpa());
//            com.setNo_of_standingarrear(company.getNo_of_standingarrear());
//            com.setCost_to_company(company.getCost_to_company());
//            com.setDeadline_to_apply(company.getDeadline_to_apply());
//            return companyRepo.save(com);
//        }



        public Company getCompanyById ( int id)
        {
            return companyRepo.findById(id).orElse(null);
        }

    public List<Company> getAllCompanies() {
        return companyRepo.findAll();
    }


}
