package com.bootapp.placemenportal.repository;

public interface QueriesRepo {
}
