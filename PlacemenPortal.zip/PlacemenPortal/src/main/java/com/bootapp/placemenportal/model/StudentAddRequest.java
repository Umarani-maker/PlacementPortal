package com.bootapp.placemenportal.model;

import lombok.AllArgsConstructor;
import lombok.Data;

import javax.persistence.Column;

@Data
public class StudentAddRequest {


    private int student_id;
    private String student_name;
    private int reg_num;
    private String email_id;
    private Long ph_no;
    private String department;
    private float student_10th_aggregate;
    private float student_12th_aggregate;
    private float student_cgpa;
    private int student_standing_arrear;
    private int admin_id;

}
