package com.bootapp.placemenportal.repository;

import com.bootapp.placemenportal.entity.Student;
import com.bootapp.placemenportal.entity.StudentRegistration;
import org.springframework.data.jpa.repository.JpaRepository;

public interface StudentRegistrationRepo extends JpaRepository<StudentRegistration,Integer> {
}
