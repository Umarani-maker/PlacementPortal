package com.bootapp.placemenportal.controller;

import com.bootapp.placemenportal.entity.StudentRegistration;

import com.bootapp.placemenportal.model.StudentRegistrationAddRequest;
import com.bootapp.placemenportal.service.StudentRegistrationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;

@RestController
public class StudentRegistrationController {

        @Autowired
        private StudentRegistrationService studentRegistrationService ;


//        @PostMapping("/addStudentRegistration")
//        public  StudentRegistration postDetails(@RequestBody StudentRegistrationAddRequest studentRegistration)
//        {
//            return studentRegistrationService.saveDetails(studentRegistration);
//
//        }
            @PostMapping("/addStudentRegistration")
            public  StudentRegistration postDetails(@RequestParam("skillset") String skillset,
                                                    @RequestParam("password") String password,
                                                    @RequestParam("resume")MultipartFile resume,
                                                    @RequestParam("email_id") String email_id)throws IOException

            {
                return studentRegistrationService.saveDetails(skillset,password,resume,email_id);

            }

    }
