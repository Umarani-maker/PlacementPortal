package com.bootapp.placemenportal.repository;

import com.bootapp.placemenportal.entity.Company;
import com.bootapp.placemenportal.entity.Tracking;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface TrackingRepo extends JpaRepository<Tracking , Integer> {
    @Query("SELECT c FROM Company c WHERE c.id NOT IN " +
            "(SELECT t.company.id FROM Tracking t WHERE t.student.id = :studentId)")
    List<Company> findCompaniesNotAppliedByStudent(int studentId);


//    @Query("SELECT DISTINCT t.company FROM Tracking t WHERE t.student.id = :studentId")
      @Query("SELECT t FROM Tracking t JOIN FETCH t.company WHERE t.student.id = :studentId")
      List<Tracking> findAppliedCompaniesByStudent(int studentId);

}
