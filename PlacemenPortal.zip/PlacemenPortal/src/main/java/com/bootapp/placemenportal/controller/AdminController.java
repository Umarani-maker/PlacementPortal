package com.bootapp.placemenportal.controller;

import com.bootapp.placemenportal.entity.Admin;
import com.bootapp.placemenportal.model.AdminAddRequest;
import com.bootapp.placemenportal.service.AdminService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class AdminController {

        @Autowired
        private AdminService adminService ;


        @PostMapping("/addAdmin")
        public Admin postDetails(@RequestBody AdminAddRequest admin)
        {
           return adminService.saveDetails(admin);


        }

    }
