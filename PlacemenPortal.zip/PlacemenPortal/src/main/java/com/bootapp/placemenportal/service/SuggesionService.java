package com.bootapp.placemenportal.service;


import com.bootapp.placemenportal.entity.Student;
import com.bootapp.placemenportal.entity.Suggestion;
import com.bootapp.placemenportal.entity.Suggestion;
import com.bootapp.placemenportal.model.SuggestionAddRequest;
import com.bootapp.placemenportal.repository.StudentRepo;
import com.bootapp.placemenportal.repository.SuggestionRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class SuggesionService {

    @Autowired
    private SuggestionRepo suggestionRepo;

    @Autowired
    private StudentRepo student;

    public Suggestion saveDetails(SuggestionAddRequest suggestion)
    {
        Suggestion sug=new Suggestion();
        sug.setSuggestion(suggestion.getSuggestion());


       //Role-> table->username ->
        return suggestionRepo.save(sug);
    }
}
