package com.bootapp.placemenportal.model;

import lombok.Data;
@Data
public class StudentRegistrationAddRequest{

        private byte[] resume;
        private String Skillset;
        private String email;
        private String password;

}
