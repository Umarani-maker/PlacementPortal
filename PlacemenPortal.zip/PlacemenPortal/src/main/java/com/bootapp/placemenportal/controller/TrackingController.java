package com.bootapp.placemenportal.controller;

import com.bootapp.placemenportal.entity.Company;
import com.bootapp.placemenportal.entity.Tracking;
import com.bootapp.placemenportal.service.StudentService;
import com.bootapp.placemenportal.service.TrackingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin("*")
public class TrackingController {


    @Autowired
    private TrackingService trackingService;
    @GetMapping("/alltracking")
    public List<Tracking> getAllTrackingData() {
        return trackingService.getAllTrackingData();
    }

    @GetMapping("/allcompanies/{studentId}")
    public ResponseEntity<List<Company>> getCompaniesNotAppliedByStudent(@PathVariable int studentId) {
        List<Company> companies = trackingService.findCompaniesNotAppliedByStudent(studentId);
        return ResponseEntity.ok(companies);
    }

    @GetMapping("/appliedcompanies/{studentId}")
    public ResponseEntity<List<Tracking>> getAppliedCompaniesByStudent(@PathVariable int studentId) {
        List<Tracking> appliedCompanies = trackingService.findAppliedCompaniesByStudent(studentId);
        return ResponseEntity.ok(appliedCompanies);
    }

    @PostMapping("/apply")
    public ResponseEntity<String> applyToCompany(@RequestBody Tracking tracking) {
        Tracking appliedTracking = trackingService.applyToCompany(tracking);
        return ResponseEntity.ok("Application submitted successfully.");
    }


}
