package com.bootapp.placemenportal.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.*;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.*;

import java.util.Date;

@Entity
@Data
@Table(name="placement_company")
@NoArgsConstructor
@AllArgsConstructor
public class Company {

    @Id
    @Column(name="company_id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int company_id;

    @Column(name="aggregate_10th")
    private float aggregate_10th;

    @Column(name="aggregate_12th")
    private float aggregate_12th;

    @Column(name="company_name")
    private String company_name;

   @Lob
   private byte[] company_logo;

    @Column(name="company_url")
    private String company_url;

    @Column(name="cost_to_company")
    private long cost_to_company;

    @Column(name="deadline_to_apply")
    @DateTimeFormat(pattern = "dd/MM/yyyy")
    @JsonFormat(shape = JsonFormat.Shape.STRING,pattern = "dd/MM/yyyy")
    private Date deadline_to_apply;

    @Column(name="eligible_department")
    private String eligible_department;

    @Column(name="no_of_standingarrear")
    private int no_of_standingarrear;

    @Column(name="required_cgpa")
    private float required_cgpa;

}
