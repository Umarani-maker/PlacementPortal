package com.bootapp.placemenportal.model;

import lombok.Data;

@Data
public class SuggestionAddRequest {

    private String Role;
    private String username;
    private String suggestion;
}
