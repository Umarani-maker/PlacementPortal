package com.bootapp.placemenportal.service;
import com.bootapp.placemenportal.entity.StudentRegistration;
import com.bootapp.placemenportal.model.StudentRegistrationAddRequest;
import com.bootapp.placemenportal.model.StudentRegistrationAddRequest;
import com.bootapp.placemenportal.repository.StudentRegistrationRepo;
import com.bootapp.placemenportal.repository.StudentRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;

@Service
public class StudentRegistrationService {

        @Autowired
        private StudentRegistrationRepo studentRegistrationRepo;

        @Autowired
        private StudentRepo studentRepo;

//        public StudentRegistration saveDetails(StudentRegistrationAddRequest studentRegistration)
//        {
//            StudentRegistration student = new StudentRegistration();
//            int student_id = studentRepo.findStudentByemail_id(studentRegistration.getEmail());
//            student.setStudent_id(student_id);
//            student.setResume(studentRegistration.getResume());
//            student.setSkillset(studentRegistration.getSkillset());
//            student.setPassword(studentRegistration.getPassword());
//            return studentRegistrationRepo.save(student);
//        }

            public StudentRegistration saveDetails(String skillset, String password, MultipartFile resume, String email_id)throws IOException
            {
                StudentRegistration student = new StudentRegistration();
                int student_id = studentRepo.findStudentByemail_id(email_id);
                student.setStudent_id(student_id);
                student.setResume(resume.getBytes());
                student.setSkillset(skillset);
                student.setPassword(password);
                return studentRegistrationRepo.save(student);
            }

}
