package com.bootapp.placemenportal.entity;




public class Queries {



    }




