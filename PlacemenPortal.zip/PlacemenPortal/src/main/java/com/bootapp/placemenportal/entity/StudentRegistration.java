package com.bootapp.placemenportal.entity;


import lombok.*;


import javax.persistence.*;
@Getter
@Setter
@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "placement_registration")
public class StudentRegistration {

    @Id
    @GeneratedValue
    int id;

    @Lob
    private byte[] resume;

    @Column(name="Skillset")
    private String Skillset;

    @Column(name="password")
    private String password;

    @Column(name="st_register_fk")
    private int student_id;

    @OneToOne(targetEntity = Student.class ,cascade = CascadeType.ALL)
    @JoinColumn(name = "st_register_fk",referencedColumnName ="student_id",insertable = false,updatable = false)
    private Student student;




}
