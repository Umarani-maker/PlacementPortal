package com.bootapp.placemenportal.service;

import com.bootapp.placemenportal.entity.Student;
import com.bootapp.placemenportal.entity.StudentRegistration;
import com.bootapp.placemenportal.model.StudentAddRequest;
import com.bootapp.placemenportal.repository.StudentRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.CrossOrigin;

import java.util.List;
@CrossOrigin("*")
@Service
public class StudentService {
    @Autowired
    private StudentRepo studentRepo;

    public Student saveDetails(StudentAddRequest student)
    {

        Student stu = new Student();
        stu.setStudent_id(student.getStudent_id());
        stu.setStudent_name(student.getStudent_name());
        stu.setReg_num(student.getReg_num());
        stu.setEmail_id(student.getEmail_id());
        stu.setPh_no(student.getPh_no());
        stu.setDepartment(student.getDepartment());
        stu.setStudent_10th_aggregate(student.getStudent_10th_aggregate());
        stu.setStudent_12th_aggregate(student.getStudent_12th_aggregate());
        stu.setStudent_cgpa(student.getStudent_cgpa());
        stu.setStudent_standing_arrear(student.getStudent_standing_arrear());
        stu.setAdmin_id(student.getAdmin_id());
        return studentRepo.save(stu);
    }


    public Student getStudentDetailsById(int id)
    {
        return studentRepo.findById(id).orElse(null);
    }

    public Student updateDetails(Student student)
    {
        Student updateStudent= studentRepo.findById(student.getStudent_id()).orElse(null);
        if(updateStudent!=null)
        {
            updateStudent.setStudent_name(student.getStudent_name());
            updateStudent.setDepartment(student.getDepartment());
            studentRepo.save(updateStudent);
            return updateStudent;
        }
        return null;
    }


    public String deleteStudent(int id)
    {
        studentRepo.deleteById(id);
        return "deleted"+id;
    }

    public List<Student> getAllStudents() {
        return studentRepo.findAll();
    }

    public Student getStudentByEmail(String emailId) {
        // Implement a custom method in the repository to find a student by email
        return studentRepo.findByEmailId(emailId);
    }






}


