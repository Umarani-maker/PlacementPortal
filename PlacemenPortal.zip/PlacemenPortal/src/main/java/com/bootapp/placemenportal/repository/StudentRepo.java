package com.bootapp.placemenportal.repository;


import com.bootapp.placemenportal.entity.Student;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface StudentRepo extends JpaRepository<Student,Integer> {

    @Query(value = "Select student_id from placement_student where email_id =:email",nativeQuery = true)
    public  int findStudentByemail_id(String email);


    @Query("SELECT s FROM Student s WHERE s.email_id = :emailId")
    Student findByEmailId(String emailId);
}
