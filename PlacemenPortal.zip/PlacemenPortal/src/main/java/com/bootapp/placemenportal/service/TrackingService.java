package com.bootapp.placemenportal.service;

import com.bootapp.placemenportal.entity.Company;
import com.bootapp.placemenportal.entity.Tracking;
import com.bootapp.placemenportal.repository.StudentRepo;
import com.bootapp.placemenportal.repository.TrackingRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TrackingService {
    @Autowired
    private TrackingRepo trackingRepo;

    public List<Tracking> getAllTrackingData() {
        return trackingRepo.findAll();
    }

    public Tracking applyToCompany(Tracking tracking) {
        // Set the status to "InProgress"
        tracking.setStatus("InProgress");

        // Save the tracking entry to the database
        return trackingRepo.save(tracking);
    }

    public List<Company> findCompaniesNotAppliedByStudent(int studentId) {
        return trackingRepo.findCompaniesNotAppliedByStudent(studentId);
    }

    public List<Tracking> findAppliedCompaniesByStudent(int studentId) {
        return trackingRepo.findAppliedCompaniesByStudent(studentId);
    }
}
