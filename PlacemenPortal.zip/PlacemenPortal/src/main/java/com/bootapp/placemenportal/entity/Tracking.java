package com.bootapp.placemenportal.entity;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;



import javax.persistence.*;
@Data
@Table(name="placement_tracking")
@NoArgsConstructor
@AllArgsConstructor
@Entity

public class Tracking {

//        @Id
//        @GeneratedValue(strategy = GenerationType.IDENTITY)
//        private int tracking_id;
//
//        @ManyToOne(cascade = CascadeType.ALL ,targetEntity =Student.class)
//
//        @JoinColumn(name="st_tr_id",referencedColumnName ="student_id",insertable = false,updatable = false)
//        private Student student;
//
//        @ManyToOne(cascade = CascadeType.ALL ,targetEntity = Company.class)
//
//        @JoinColumn(name="c_tr_id",referencedColumnName ="company_id",insertable = false,updatable = false)
//        private Company company;
//
//        @Column
//        private String status;

                @Id
                @GeneratedValue(strategy = GenerationType.IDENTITY)
                @Column(name = "tracking_id")
                private int trackingId;

                @ManyToOne
                @JoinColumn(name = "st_tr_id", referencedColumnName = "student_id")
                @JsonProperty("st_tr_id")
                private Student student;

                @ManyToOne
                @JoinColumn(name = "cp_tr_id", referencedColumnName = "company_id")
                @JsonProperty("cp_tr_id")

                private Company company;

                @Column(name = "status")
                private String status;




}
