package com.bootapp.placemenportal.repository;

import com.bootapp.placemenportal.entity.Suggestion;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SuggestionRepo extends JpaRepository<Suggestion,Integer>{
}
