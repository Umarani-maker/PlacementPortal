package com.bootapp.placemenportal.service;

public class QueriesService {
}
