package com.bootapp.placemenportal.controller;

public class QueriesController {
}
