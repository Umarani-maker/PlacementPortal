package com.bootapp.placemenportal.model;

import lombok.Data;

import javax.persistence.Column;
@Data
public class AdminAddRequest {


    private int admin_id ;
    private String admin_name ;
    private String admin_email_id;
    private String admin_password;
    private int suggestion_id;
}
