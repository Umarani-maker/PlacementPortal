package com.bootapp.placemenportal.entity;

import jdk.jshell.SourceCodeAnalysis;
import lombok.*;

import javax.persistence.*;
import java.util.Set;
@Getter
@Setter
@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "placement_admin")
public class Admin{

        @Id
        @GeneratedValue
        @Column(name="admin_id")
        private int admin_id ;

        @Column(name="admin_name")
        private String admin_name ;

        @Column(name="admin_email_id")
        private String admin_email_id;

        @Column(name="admin_password")
        private String admin_password;

        @OneToMany(cascade = CascadeType.ALL ,targetEntity = Suggestion.class)
        @JoinColumn(name="ad_suggest_id",insertable = false,updatable = false)
        private Set<SourceCodeAnalysis.Suggestion> suggestion;


    }
