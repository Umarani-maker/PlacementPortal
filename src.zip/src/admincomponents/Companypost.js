import Adminheader from "./Adminheader";
import "./Admincss/Companypost.css"
import React, { useState } from 'react';
import axios from 'axios';
import { format } from 'date-fns';

const Companypost = () => {


  const [aggregate_10th , setAggregate_10th] = useState();
  const [aggregate_12th , setAggregate_12th] = useState();
  const [required_cgpa,setRequired_cgpa] = useState();
  const [cost_to_company,setCost_to_company] = useState();
  const [no_of_standingarrear,setNo_of_standingarrear] = useState();
  const [company_name,setCompany_name] = useState('');
  const [company_logo,setCompany_logo] = useState(null);
  const [company_url,setCompany_url] = useState('');
  const [eligible_departments,setEligible_departments] = useState('');
  const [deadline_to_apply,setDeadline_to_apply]= useState();



  function handleSubmit(e) {
    e.preventDefault();
    console.log(aggregate_10th);

    const formData = new FormData();
    formData.append('aggregate_10th', aggregate_10th);
    formData.append('company_name', company_name);
    formData.append('aggregate_12th', aggregate_12th);
    formData.append('required_cgpa', required_cgpa);
    formData.append('cost_to_company', cost_to_company);
    formData.append('no_of_standingarrear', no_of_standingarrear);
    formData.append('company_logo', company_logo);
    formData.append('company_url', company_url);
    formData.append('eligible_departments', eligible_departments);
    formData.append('deadline_to_apply', deadline_to_apply);

    console.log(formData.get('required_cgpa'));

    const companypostUrl = 'http://localhost:8080/addCompany';

    axios
      .post(companypostUrl, formData,{
        headers: {
            'Content-Type': 'multipart/form-data',
          },
      })
      .then((response) => {
        console.log(response);
      })
      .catch((error) => {
        console.error('Error posting company info:', error.response.data);
      });
  }


  
    return (
        <div className="form">
            <Adminheader></Adminheader>
           
           <form onSubmit={handleSubmit}>
                <div className="form-control">


                    <h2 className="companyh"> WELCOME ADMIN TO PLACEMENT PORTAL </h2>
                    <label> Company name :   </label>
                    <input type="text" onChange={(e) => setCompany_name(e.target.value)}/>
                    <label>Company Url :     </label>
                    <input type="text" onChange={(e) => setCompany_url(e.target.value)}/>
                    <label>Company logo</label>
                    <input type="file"onChange={(e) => setCompany_logo(e.target.files[0])}></input>

                    <label> Eligible Department :  </label>
                    <input type="text" onChange={(e) => setEligible_departments(e.target.value)}/>
                    <label> 10th aggregate :  </label>
                    <input type="text" onChange={(e) => {const inputValue = parseFloat(e.target.value); 
                        setAggregate_10th(inputValue)}}/>
                    <label> 12th aggregate :  </label>
                    <input type="text" onChange={(e) => {const inputValue = parseFloat(e.target.value); 
                        setAggregate_12th(inputValue)}}/>
                    <label> Required CGPA :  </label>
                    <input type="text" onChange={(e) => {const inputValue = parseFloat(e.target.value); 
                        setRequired_cgpa(inputValue)}}/>
                    <label> No.of standing arrear:  </label>
                    <input type="text" onChange={(e) => {const inputValue = parseInt(e.target.value); 
                        setNo_of_standingarrear(inputValue)}}/>
                    
                    <label> Cost to company:  </label>
                    <input type="text" onChange={(e) => {const inputValue = parseInt(e.target.value,10); 
                        setCost_to_company(inputValue)}}/>

                    <label> Due date to apply :  </label>
                    <input type="text" onChange={(e) => {
                                const inputValue = new Date(e.target.value); // Parse as a Date object
                                const formattedDate = format(inputValue, 'dd/MM/yyyy'); // Format as desired yyyy-MM-dd
                                setDeadline_to_apply(formattedDate);
  }}/>
                    <button id="btn" type="submit"> Post</button>
                    </div>
           </form>

        </div>
    )
}

export default Companypost;