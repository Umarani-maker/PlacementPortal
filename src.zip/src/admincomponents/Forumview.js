
import Adminheader from "./Adminheader";

const Forumview = () => {
    return (
        <div>
            <Adminheader></Adminheader>
            <h3>view the queries here</h3>
        </div>
    )
}

export default Forumview;