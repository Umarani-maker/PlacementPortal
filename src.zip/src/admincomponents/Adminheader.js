import React from "react";
import "./Admincss/Adminheader.css"
const Adminheader = () => {
    return (
        <div>
            <header>
                <nav>
                    <a class="companypost" href="/companypost"><button className="ab">COMPANYPOST</button></a>
                    <a class="details" href="/details"><button className="ab">DETAILS</button></a>
                    <a class="forumview" href="/forumview"><button className="ab">QUERYVIEW</button></a>
                </nav>
            </header>
        </div>
    )
}

export default Adminheader;