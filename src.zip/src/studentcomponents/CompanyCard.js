// import React from 'react';
import "./Studentcss/CompanyCard.css"
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Link } from "react-router-dom";
import iconalumin from "../images/iconalumin.png"


function CompanyCard(props) {

  const {company , student} = props;
  const [isEligible,setIsEligible ]= useState(true);

  const [status, setStatus] = useState('');
  

  const Checkcry = () => {
    const f = student.student_10th_aggregate>=company.aggregate_10th;
    const s = student.student_12th_aggregate>=company.aggregate_12th;
    const t = student.student_cgpa >= company.required_cgpa;

    if(f && s && t){
      setIsEligible(false);

    }
    else{
      setIsEligible(true);
    }
    
    
    
  }


  
  const handleApplyClick = () => {
    // Create the tracking object with the studentId, companyId, and status
    const track = {
      st_tr_id: student,
      cp_tr_id: company,
      status: 'InProgress', // Set the status to "InProgress"
    };
    console.log(track);
    const apitrackingUrl = 'http://localhost:8080/apply';
    // Make a POST request using Axios
    axios.post(apitrackingUrl, track)
      .then((response) => {
        // Handle the response, e.g., display a success message
        setStatus(response.data);
        console.log('company moved')
      })
      .catch((error) => {
        console.log('cant move the company')
        console.error('Error:', error);
      });
  };

  
  

  return (

    <div className="company-card" onClick={Checkcry}>
      <img src={iconalumin} className="iconal" alt="icon"></img>
      <a className="name" href={company.company_url}>{company.company_name}</a>
      <br></br>
      <br></br>
      
      

      <label className="cgpa">Required CGPA:</label> <p>{company.required_cgpa}</p>

      
      <br></br>
      <br></br>
      <label>Eligible Courses:</label> <p>{company.eligible_department}</p>
      <br></br>
      <br></br>
      <label>Cost to Company:</label> <p>{company.cost_to_company}</p>
      <br></br>
      <br></br>
      <label>Due to apply:</label > <p >{company.deadline_to_apply}</p>

      <br></br>
      <br></br>

      <Link to="/applied"><button  disabled={isEligible} onClick={handleApplyClick} className="ap">apply</button></Link>
      
      {/* <button  disabled={isEligible} onClick={handleApplyClick} >apply</button> */}
      
      

    </div>
  );
}

export default CompanyCard;
