import React, { useState, useEffect } from 'react';
import Studentheader from "./Studentheader";
import "./Studentcss/Applied.css";
import axios from 'axios';
import tick from "../images/tick.png"
import applied from "../images/applied.png"
const Applied = () => {
    const [email, setEmail] = useState();
   
    const [appliedCompanies, setAppliedCompanies] = useState([]);
    const [student,setStudent]= useState({});

    // useEffect(()=>{
    //   const storedEmail = localStorage.getItem('userEmail');
    //   if(storedEmail){
    //     setEmail(storedEmail);
    //   }

    // },[]);


    useEffect(() => {
      const storedEmail = localStorage.getItem('userEmail');
      if(storedEmail){
        setEmail(storedEmail);
      }
      console.log(storedEmail);
   
      const apistudentUrl = `http://localhost:8080/student/${encodeURIComponent(storedEmail)}`;

      
      
        axios
        .get(apistudentUrl)
        .then((response) => {
          setStudent(response.data);
          
          console.log('Applied student fetched');
          const studentId = response.data.student_id; 
          const apitrackingUrl = `http://localhost:8080/appliedcompanies/${encodeURIComponent(studentId )}`;
        axios
        .get(apitrackingUrl)
        .then((response) => {
          setAppliedCompanies(response.data);
          console.log("applied compnies fetched")
          
          
        })
        .catch((error) => {
          console.error('Error fetching company info:', error);
        });
          
          
        })
        .catch((error) => {
          console.error('Error fetching student info:', error);
        });

        


      


    }, []);

    

    return (
        <div>
            <Studentheader></Studentheader>
            <div className="content">
        <h1 className="head">APPLIED COMPANIES</h1>
        {/* EMAIL<p>{email}</p> */}
        <div className="appliedcompany-list">
          {appliedCompanies.map(company => (
            <div key={company.id} className="appliedcompany-card">
              <h2 className='Aname'>{company.cp_tr_id.company_name}</h2>

               <div className='appi'>
                  <img src={applied} alt="appl" className='apply'></img>
                  <p class="sta">Status: {company.status}</p>
               </div>

               <div>
                  <img src={tick} className="tick" alt="icon"></img>
                  {/* <a className='Aname' href={company.cp_tr_id.company_url}>{company.cp_tr_id.company_name}</a> */}
                  
                  
               </div>

              
            </div>
          ))}
        </div>
      </div>
        </div>
    )
}

export default Applied;