import React from "react";
import "./Studentcss/Studentheader.css"
import cplogo from '../images/cplogo.jpg'
const Studentheader = () => {
    return (
        <div>
            <header>
                <nav>
                    {/* <img src={cplogo}></img> */}
                    <a class="jobs" href="/jobs" ><button className="sb">JOBS</button></a>
                    <a class="applied" href="/applied"><button className="sb">APPLIED</button></a>
                    <a class="forum" href="/forum"><button className="sb">FORUM</button></a>
                </nav>
            </header>
        </div>
    )
}

export default Studentheader;