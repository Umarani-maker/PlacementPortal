import Studentheader from "./Studentheader";
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import CompanyCard from './CompanyCard'; 
import Applied from "./Applied";
import "./Studentcss/Job.css"

const Jobs = ({username}) => {
    const [email, setEmail] = useState(username);
    
    const [eligibleCompanies, setEligibleCompanies] = useState([]);
    const [student,setStudent]= useState({});
    

   
   
    useEffect(() => {
      const storedEmail = localStorage.getItem('userEmail');
      if(storedEmail){
        setEmail(storedEmail);
      }
      console.log(storedEmail);
        
   
        const apistudentUrl = `http://localhost:8080/student/${encodeURIComponent(storedEmail)}`;

        
        
          axios
          .get(apistudentUrl)
          .then((response) => {
            setStudent(response.data);
            
            console.log('student data fetched successfully');
            const studentId = response.data.student_id; 
            const apicompanyUrl = `http://localhost:8080/allcompanies/${encodeURIComponent(studentId )}`;
          axios
          .get(apicompanyUrl)
          .then((response) => {
            setEligibleCompanies(response.data);
            
            
          })
          .catch((error) => {
            console.error('Error fetching company info:', error);
          });
            
            
          })
          .catch((error) => {
            console.error('Error fetching student info:', error);
          });

          


        


      }, []);
      
    return (
      
        
        <div >
            <Studentheader></Studentheader>
            <h2 className="comph">WELCOME {student.student_name}</h2>
            
            <div className="company-card-container">
               {eligibleCompanies.map(company => (
               <CompanyCard key={company.id} company={company} student={student} />
                ))}
           </div>

            
        </div>
    )
}

export default Jobs;