import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import "./frontendcss/login.css"
import welcome from "../images/welcome.jpg"

function Login({ onLogin }) {

  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  // const [role, setRole] = useState('');
  const localStorageKey = 'userEmail';

  useEffect(() => {
    const storedEmail = localStorage.getItem(localStorageKey);
    if (storedEmail) {
      setUsername(storedEmail);
    }
  }, []);

  useEffect(() => {
    localStorage.setItem(localStorageKey, username);
  }, [username]);


  const handleLoginClick = () => {
    let role = '';
    if (username && password) {
      if (username === 'admin10@gmail.com') {
        role = 'admin';
      } else {
        role = 'student';
      }
      onLogin(username, role);
    }
    
  };

  
  
  return (
 
  
  <>

      <h1 className='lh'>PLACEMENT PORTAL</h1>
        <div className="login">
      
      <div className='lf'>
       <img src={welcome} className='lim'></img>

      </div>

      <div className='lf'>
         <form className='fn'>
           <label className='loginlab'>EmailID:</label>

           <input className="linp" onChange={(e) => setUsername(e.target.value)}></input>
           <label className='loginlab'>Password: </label>
           <input type="password" className="linp"  onChange={(e) => setPassword(e.target.value)}></input>
           <button onClick={handleLoginClick} className='logbt'>LOGIN</button>
           <a href="/signup" className='sina'>Don't have an account click here</a>
         </form>
         
      </div>
   








     {/* <form>
       EmailID: <input onChange={(e) => setUsername(e.target.value)}></input>
       Password: <input onChange={(e) => setPassword(e.target.value)}></input>
       <button onClick={handleLoginClick}>LOGIN</button>
       
     </form> */}
   </div>
  </>
    
  );
}

export default Login;
