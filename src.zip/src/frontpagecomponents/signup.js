import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Link } from "react-router-dom";
import './frontendcss/signup.css'; // Import your CSS file

function Signup() {
  const [email_id, setEmail_id] = useState('');
  const [password, setPassword] = useState('');
  const [skillset, setSkillset] = useState('');
  const [resume, setResume] = useState(null);

  const localStorageKey = 'userEmail';

  useEffect(() => {
    const storedEmail = localStorage.getItem(localStorageKey);
    if (storedEmail) {
      setEmail_id(storedEmail);
    }
  }, []);

  useEffect(() => {
    localStorage.setItem(localStorageKey, email_id);
  }, [email_id]);

  function handleSubmit(e) {
    e.preventDefault();

    const formData = new FormData();
    formData.append('email_id', email_id);
    formData.append('password', password);
    formData.append('skillset', skillset);
    formData.append('resume', resume);

    const signupUrl = 'http://localhost:8080/addStudentRegistration';

    axios
      .post(signupUrl, formData)
      .then((response) => {
        console.log(response);
        console.log("signup registration suceesfuly");
      })
      .catch((error) => {
        console.error('Error posting registration info:', error);
        console.log("error in registering the stufent");
      });
  }

  return (
    <>
        <h1>PLACEMENT PORTAL</h1>
    <div className="signup-container">
      <div className="signup-image">
        {/* Add your image here */}
        <img className='image-signup' src="https://img.freepik.com/premium-photo/illustration-woman-working-remotely-laptop-computer-white-background_962751-2752.jpg" alt="Signup Image" />
      </div>
      <div className="signup-form">
        <h2 className='sigh'>Sign Up</h2>
        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label className='siglab'>Email:</label>
            <input
              className='sigin'
              type="email"
              name="email"
              value={email_id}
              onChange={(e) => setEmail_id(e.target.value)}
              required
            />
          </div>
        
          <div className="form-group">
            <label>Password:</label>
            <input
              className='sigin'
              type="password"
              name="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </div>

          <div className="form-group">
            <label>Confirm Password:</label>
            <input
              className='sigin'
              type="password"
              name="password"
              
              required
            />
          </div>

          <div className="form-group">
            <label>Resume (PDF):</label>
            <input
              className='sigin'
              type="file"
              accept=".pdf"
              name="resume"
              onChange={(e) => setResume(e.target.files[0])}
              required
            />
          </div>


          <div className="form-group">
            <label>Skills:</label>
            <input
              type="text"
              className='sigin'
              name="skills"
              value={skillset}
              onChange={(e) => setSkillset(e.target.value)}
              required
            />
          </div>
          <div className="form-group">
            <Link to="/jobs"><button type="submit" className='sigbt'>Sign Up</button></Link>
          </div>
        </form>
      </div>
    </div>
    </>
  );
}

export default Signup;
