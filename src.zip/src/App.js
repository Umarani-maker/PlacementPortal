import logo from './logo.svg';
import './App.css';
import Approuter from './Approuter';
function App() {
  return (
    <div>
      <Approuter></Approuter>
    </div>
  );
}

export default App;
